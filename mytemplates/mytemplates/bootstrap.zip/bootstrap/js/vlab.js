$(function () {
	$(document).ready(function() {
		$("#listteachers").click(function()
		{
			$.getJSON(
				"listteachers/",
 	                       	function(result){
                                	var tb_body = "";
					var link = "";
                                	$.each(result, function(){
                                        	var tb_row = "";
                                        	$.each(this, function(k,v){
                                               		if(k=="teacherID") {
		                                                link = "<a href=listteacherbyID/"+v+">"+v+"</a>";
								tb_row += "<td>"+link+"</td>";
							}
							else
								tb_row += "<td>"+v+"</td>";
                                        	})
                                        	tb_row += "<td><button class='btn btn'>delete</button><button class='btn btn'>modify</button></td>";
                                        	tb_body += "<tr>"+tb_row+"</tr>";
                                	})
                                	$("#teachersbody").html(tb_body);
                        	}
                	);
		});
		$("#liststudents").click(function()
          	{
                	$.getJSON(
		                "liststudents/",
		                function(result){
		                        var tb_body = "";
		                        var link = "";
		                        $.each(result, function(){
		                                var tb_row = "";
		                                $.each(this, function(k,v){
		                                        if(k=="studentID"){
		                                                link = "<a href=liststudentbyID/"+v+">"+v+"</a>";
		                                                tb_row += "<td>"+link+"</td>";
		                                        }
		                                        else
		                                                tb_row +="<td>"+v+"</td>";
		                                })
		                                tb_row += "<td><button class='btn btn'>delete</button><button class='btn btn'>modify</button></td>";
		                                tb_body += "<tr>"+tb_row+"</tr>";
		                        })
		                        $("#studentsbody").html(tb_body);
		                }
                	);      
          	});

		
	});
});
