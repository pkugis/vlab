$(function () {
	$(document).ready(function() {
		$("#btn1").click(function()
		{
			$("#1C").clear();
			$("#1C").html("c");
		});
	}
}